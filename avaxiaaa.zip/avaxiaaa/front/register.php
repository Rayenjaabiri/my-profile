<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'] ?? '';
  $password = $_POST['password'] ?? '';

  if ($username && $password) {
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");

    try {
      $stmt->execute([$username, $hashed]);
      echo "success";
    } catch (PDOException $e) {
      echo "error"; // utilisateur existe déjà
    }
  } else {
    echo "missing";
  }
}
?>
